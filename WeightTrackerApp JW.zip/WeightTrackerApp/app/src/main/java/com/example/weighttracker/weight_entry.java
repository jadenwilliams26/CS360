package com.example.weighttracker;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;


public class weight_entry extends AppCompatActivity {

    protected EditText dateEntry;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_entry);

        dateEntry = findViewById(R.id.editWeightDate);

        dateEntry.setOnClickListener(v -> {
            // the instance of our calendar.
            final Calendar c = Calendar.getInstance();

            // our day, month and year.
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // creating a variable for date picker dialog.
            @SuppressLint("SetTextI18n") DatePickerDialog datePickerDialog = new DatePickerDialog(
                    // passing context.
                    weight_entry.this,
                    (view, year1, monthOfYear, dayOfMonth) -> {
                        // setting date to our edit text.
                        dateEntry.setText((monthOfYear + 1) + "-" + dayOfMonth  + "-" + year1);

                    },
                    // passing year month and day for selected date in our date picker.
                    year, month, day);
            // calling show to display our date picker dialog.
            datePickerDialog.show();
        });
    }

    public void openMainForm(View view){
        Intent intent = new Intent(this, main_screen.class);
        startActivity(intent);
    }
}